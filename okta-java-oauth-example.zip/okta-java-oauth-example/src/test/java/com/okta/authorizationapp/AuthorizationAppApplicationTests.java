package com.okta.authorizationapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthorizationAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
